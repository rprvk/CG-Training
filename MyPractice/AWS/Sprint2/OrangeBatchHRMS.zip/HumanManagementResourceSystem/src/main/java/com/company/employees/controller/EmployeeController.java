package com.company.employees.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.company.employees.entity.Admin;
import com.company.employees.entity.Employee;
import com.company.employees.service.AdminService;
import com.company.employees.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@GetMapping("/")
	public String login(Model m) {		
		return "login";
	}
	
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public String validate(Model m, @RequestParam String email, @RequestParam String password) {
		List<Admin> admins = adminService.getAllAdmin();
		
		for (Admin a : admins) {
			System.out.println(bCryptPasswordEncoder.encode(password));
			if (a.getEmail().equals(email) && bCryptPasswordEncoder.matches(password, a.getPassword())) {			
				return "redirect:/dashboard/"+a.getId();
			}
		}

		m.addAttribute("error", "Invalid credentials.");
		return "login";
	}
	
	@GetMapping("/dashboard/{id}")
	public String dashboard(@PathVariable int id, Model m, HttpSession session) {
		
		Admin admin = adminService.getById(id);
		m.addAttribute("user", admin);
		
		session.setAttribute("userid", id);
		
		return "dashboard";
	}
	
	@GetMapping("/home")
	public String home(Model m) {
		
		List<Employee> emp=service.getAllEmp();
		m.addAttribute("emp", emp);
		
		return "index";
	}
	
	@GetMapping("/addemp")
	public String addEmployee() {
		return "addEmp";
	}
	
	@GetMapping("/signup")
	public String signup() {
		return "signup";
	}
	
	@PostMapping("/register")
	public String empRegister(@ModelAttribute Employee e, HttpSession session) {
		e.setDisabled(false);
		service.addEmp(e);
		session.setAttribute("msg","Employee Added Successfully");
		return "redirect:/home";
	}
	
	@PostMapping("/createadmin")
	public String signup(@ModelAttribute Admin a, HttpSession session) {
		String encodedPassword = bCryptPasswordEncoder.encode(a.getPassword());
		a.setPassword(encodedPassword);
		adminService.addAdmin(a);
		session.setAttribute("msg","Your account is successfully created.");
		return "redirect:/dashboard/"+a.getId();
	}
	
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id,Model m) {
		
		Employee e=service.getEmpById(id);
		m.addAttribute("emp", e);
		return "edit";
	}
	
	@PostMapping("/update")
	public String updateEmp(@ModelAttribute Employee e, HttpSession session) {
		service.addEmp(e);
		session.setAttribute("msg", "Employee Data Updated Successfully");
		return "redirect:/home";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteEmp(@PathVariable int id, HttpSession session) {
		
		 service.deleteEmp(id);
		session.setAttribute("msg", "Employee Data Deleted Successfully");
		return "redirect:/home";
	}
}
